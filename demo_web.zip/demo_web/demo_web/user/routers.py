# coding=utf-8
from demo_web.routers import ComposableRouter
from demo_web.user.controllers import UserController


class Router(ComposableRouter):

    def add_routes(self, mapper):
        ctrl = UserController()
        mapper.connect('/users', controller=ctrl,
                       conditions=dict(method=['GET']))
        mapper.connect('/users/{userid}', controller=ctrl,
                       action='get_user', conditions=dict(method=['GET']))
