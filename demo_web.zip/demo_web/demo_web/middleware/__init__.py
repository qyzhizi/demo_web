# coding=utf-8
from demo_web.middleware.core import (CookieAuthMiddleware,
                                       AccessKeyAuthMiddleware,
                                       InternalServiceAuthMiddleware,
                                       SysLogMiddleware,
                                       PagingMiddleware,
                                       ResourceMiddleware)
