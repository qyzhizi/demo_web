# coding=utf-8
from demo_web.routers import Version, ComposingRouter
import demo_web.user.routers as user


def add_routers(modules):
    # router must be of type smartcontrol.wsgi.ComposableRouter
    return [m.Router() for m in modules]


def version_app_factory(global_cfg, **local_cfg):
    modules = [user]
    sub_routers = add_routers(modules)
    sub_routers.append(Version())
    return ComposingRouter(routers=sub_routers)
