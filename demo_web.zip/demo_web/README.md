# demo_web
基于Paste, PasteDeploy, Routes 和 WebOb 搭建的一套Web框架demo
转载自 https://github.com/zjyExcelsior/zjy_webob
